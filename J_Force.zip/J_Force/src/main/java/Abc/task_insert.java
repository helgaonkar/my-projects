package Abc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class task_insert
 */
@WebServlet("/task_insert")
public class task_insert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public task_insert() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		
		PrintWriter out=response.getWriter();
		
		String s=request.getParameter("date");
		String s1=request.getParameter("text");
  
		try {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hdb","root","");
		PreparedStatement pt=con.prepareStatement("insert into Task values(?,?)");
		
		pt.setString(1, s);
		pt.setString(2, s1);

		int i=pt.executeUpdate();
		
		 pt.close();
         con.close();
		
		if(i>0) {
		
			out.println("task added successfully... ");
		}
	    } 
         catch (ClassNotFoundException | SQLException e) {
		           e.printStackTrace();
	}
		
	
		
	}

}
